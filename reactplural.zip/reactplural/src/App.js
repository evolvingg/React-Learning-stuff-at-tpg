import React,{useState} from 'react';
import logo from './logo.svg';
import './App.css';
import Button from './components/Buttons';
import Display from './components/Display';
import CardList from './components/CardList';
import {users} from './data/users';
import Form from './components/Form';
import Grid from './components/Grid';
//  gaearon , sophiebits , sebmarkbage ,bvaughn

import {connect } from 'react-redux';
import {updateUser,apiRequest} from './action-creators/user-action';

import {StarMatch} from './components/Starmatch';



// function App(props) {
//   const [counter, setCounter] = useState(20);
//   const [user , newState] = useState(users.test);
//   const handleClick = (count) => setCounter(counter*count);
//   const addNewProfile = (profileData => {
//       console.log('App::',profileData,user);
//       newState([...user,profileData]);
//   });
//   console.log('::',props);
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//       <Button onClick={handleClick} count={1}/>
//       <Button onClick={handleClick} count={2}/>
//       <Button onClick={handleClick} count={4}/>
//       <Display message={counter}/>
//       <CardList users={user}/>
//       <Form onSubmit={addNewProfile}/>
//       <Grid />
//       <div onClick={onUpdateUser.bind(this,props)}>Update user:{}</div>
//     </div>
//   );
// }

class App extends React.Component {
  constructor(props) {
    super(props);
  }

  onUpdateUser = () => {
    console.log('hi')
    this.props.onUpdateUser('sammy');
  }

  callMe = (e) => {
    this.props.onUpdateUser(e.target.value)
  }


  componentDidMount() {
    this.props.onApiRequest();
  }

  render() {
    console.log('in component::',this.props)
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
        {/* <Button onClick={handleClick} count={1}/>
        <Button onClick={handleClick} count={2}/>
        <Button onClick={handleClick} count={4}/>
        <Display message={counter}/>
        <CardList users={user}/>
        <Form onSubmit={addNewProfile}/> */}
        <Grid />
        <div onClick={this.onUpdateUser} >
          Update user:{this.props.user}
          </div>
          <input type="text" onChange={this.callMe}/>
          <StarMatch />
      </div>
    );
  }
}

const mapStateToProps = (state,props) => {
  console.log('in map:',state,props)
  return ({products:state.products, user:state.user, userPlus: `${state.user} ${props.arandomProp}`})
}

const mapActionsToProps = {
  onUpdateUser : updateUser ,
  onApiRequest : apiRequest
}

export default connect(mapStateToProps,mapActionsToProps)(App);
