import {UPDATE_USER} from '../action-creators/user-action';

export default function userReducer(state= '', action) {
    console.log('in user red ',action,state,'...',UPDATE_USER);
    switch(action.type) {
        case UPDATE_USER: 
            return action.payload.user;
        default:
            return state;
    }
}


// import {
//     FETCH_ACTIVE_MARKETS_SUCCESS,
//     FETCH_ACTIVE_MARKETS_FAILURE,
//     SHOW_LOADER,
//     UPDATE_SEARCH_SINGLE_ROW,
//     updateSingleRow,
//     CLEAN_SPECIAL_TRADED_META,
//     SHOW_LOAD_MORE_LOADER,
//     FETCH_ACTIVE_MARKET_LOAD_MORE,
//     SEARCH_REASULT_GRID_DELETE_WEBSOCKET_CHANGES,
//     SEARCH_REASULT_GRID_MESSAGE_RECEIVED,
//     FETCH_SEARCH_MARKETS_FAILURE,
//     FETCH_SEARCH,
//     FETCH_SEARCH_MARKETS_SUCCESS,
//     FETCH_SEARCH_MARKET_LOAD_MORE
// } from "../constants";
// import _ from 'lodash';
// import {applyActionToNewMessage} from "../middleware/websocket";

// const initialState = {
//     data: {},
//     showLoader: false,
//     showLoadMoreLoader: {},
//     error: null,
//     specialTradedMeta: {
//         successMsg: "",
//         orderType: ""
//     },
//     searchFilter : {
//         limit: '25',
//         offset: 0,
//         vintage : [],
//         contractType :['sib','sep','X'],
//         priceType :[],
//         lwins :[],
//         packSize :[],
//         bottleSize :[],
//         combinedFormat :[],
//         lwinGeography :'',
//         lwinColour :'',
//         minPrice :'',
//         maxPrice :'',
//         isCompetitive : undefined,
//         minQuantity :1,
//     }
// };

// const ActiveMarketReducer = (state = initialState, action) => {
//     switch (action.type) {
//         case FETCH_ACTIVE_MARKETS_SUCCESS:
//             return _.assign({}, state, {
//                 data: {...state.data,
//                     [action.key]: action.error || action.response,
//                 },
//                 showLoader:false,
//                 error: action.response.error
//             });
//         case SEARCH_REASULT_GRID_MESSAGE_RECEIVED:
//             return   _.assign({}, state,
//                 applyActionToNewMessage(state, action.payload)
//             );
//         case FETCH_ACTIVE_MARKETS_FAILURE:
//             return _.assign({}, state, {
//                 data: [],
//                 showLoader:false,
//                 error: action.error
//             });
//         case SHOW_LOADER:
//             return _.assign({}, state, {
//                 showLoader: true
//             });
//         case SHOW_LOAD_MORE_LOADER :
//             return _.assign({}, state, {
//                 showLoadMoreLoader:{[action.key]:true}
//             });
//         case FETCH_ACTIVE_MARKET_LOAD_MORE:
//             return _.assign({}, state, {
//                 showLoadMoreLoader:{[action.key]:false},
//                 data: {...state.data,
//                     [action.key]:{data :[...state.data[action.key].data,...action.data.data],
//                         dataPoints: action.data.dataPoints}
//                 }
//             });
//         case UPDATE_SEARCH_SINGLE_ROW:
//             return _.assign({}, state, {
//                 data : updateSingleRow(state, action),
//                 specialTradedMeta:{
//                     successMsg: (!action.rowData || action.rowData.length === 0) ? `success.${action.orderType === 'B' ? 'S002' : 'S001'}` : '',
//                     orderType: action.orderType
//                 }
//             });
//         case CLEAN_SPECIAL_TRADED_META :
//             return {...state, specialTradedMeta : initialState.specialTradedMeta};
//         case SEARCH_REASULT_GRID_DELETE_WEBSOCKET_CHANGES:
//             let uniqueKey = action.payload.gridUniqueKey;
//             if(state.data[uniqueKey] && state.data[uniqueKey].websocketChange && state.data[uniqueKey].websocketChange[action.payload.uniqueId]) {
//                 let {[action.payload.uniqueId]: deletedKey, ...websocketChange} = state.data[uniqueKey].websocketChange; //eslint-disable-line no-unused-vars
//                 return _.assign({}, state, {
//                     data: {
//                         ...state.data,
//                         [uniqueKey]: {...state.data[uniqueKey], websocketChange}
//                     }
//                 });
//             }
//             return state;
//         case FETCH_SEARCH :
//             console.log('resp in fetch::',action.searchFilter);
//             return _.assign({}, state, {
//                 showLoader: true,
//                 searchFilter: action.searchFilter
//             });
//         case FETCH_SEARCH_MARKETS_SUCCESS: 
//             return _.assign({}, state, {
//                 data: {...state.data,
//                     [action.key]: action.error || action.response,
//                 },
//                 showLoader:false,
//                 error: action.response.error
//             });
//         case FETCH_SEARCH_MARKETS_FAILURE:
//             return _.assign({}, state, {
//                 data: [],
//                 showLoader:false,
//                 error: action.error
//             });
//         case FETCH_SEARCH_MARKET_LOAD_MORE:
//                 console.log('state in fetchmore::',state);
//             return _.assign({}, state, {
//                 showLoadMoreLoader:{[action.key]:false},
//                 data: {...state.data,
//                     [action.key]:{data :[...state.data[action.key].data,...action.data.data],
//                         dataPoints: action.data.dataPoints}
//                 }
//             });
//         default:
//             return state;
//     }
// };