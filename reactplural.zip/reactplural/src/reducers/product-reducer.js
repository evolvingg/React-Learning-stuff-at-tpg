export function productsReducer(state = [], action) {
    console.log('in products red ',action,state);
    return state;
}