import React , {useState} from 'react';

const BasicCounter = () => {
    const [count,setCount] = useState(0);
    
}
