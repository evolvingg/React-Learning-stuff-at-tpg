import React from 'react';

function Display(props){
    return (
        <div>{props.message}</div>
    )
}

export default Display;