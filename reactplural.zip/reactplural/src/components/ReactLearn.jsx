import React from 'react';
import ReactDOM from 'react-dom'; 
import {createStore} from 'redux';

function reducer(state, action) {
    return 'State';
}

const store = createStore(reducer);

console.log(store.getState());

const action = {
    type:'changeState',
    payload: {
        newState : 'New state'
    }
}

store.dispatch(action);  // sending action to store

ReactDOM.render(<App/>,document.getElementById('root'));

registerServiceWorker();

