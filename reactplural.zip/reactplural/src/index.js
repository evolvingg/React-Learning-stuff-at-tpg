import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';


// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA


import {createStore,combineReducers,applyMiddleware,compose} from 'redux';
import {Provider} from 'react-redux';
import {productsReducer} from './reducers/product-reducer';
import userReducer from './reducers/user-reducer';
import thunk from 'redux-thunk';

//reducer reads an action to update state
//reducers listen to every single action which is sent , then in reducer we decide what to do for a particular action
//1st action is init
//2nd is changeState 
const initialState = {
    user: 'Michael',
    products: [{name : 'iphone'}]
}


const allReducers = combineReducers( {
    products: productsReducer,
    user: userReducer
})
const allStoreEnhancers = compose(applyMiddleware(thunk),window.devToolsExtension && window.devToolsExtension())

const store = createStore(allReducers, initialState, allStoreEnhancers);
console.log('in store2nd::',store.getState());

// const action = {
//     type:'changeState',
//     payload: {
//         newState : 'New state'
//     }
// }


//store.dispatch(action);  // sending action to store ;dispatch an action
//console.log('in store::',store.getState());

const updateUserAction = {
    type: 'updateUser',
    payload: {
        user: 'john'
    }
}

//store.dispatch(updateUserAction); 



ReactDOM.render(
    <Provider store={store}>
        <App arandomProp="prop"/>
    </Provider>,document.getElementById('root'));

//registerServiceWorker();


serviceWorker.unregister();
