let express = require('express');
let app = express();

app.set('view engine', 'ejs');

app.get('/', (req, res) => res.render('index'));
let port = 4000;
app.listen(port, () => console.log(`app at http://localhost:${port}`));




