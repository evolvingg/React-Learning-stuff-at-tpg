const cluster = require('cluster');
const os = require('os');
const express = require('express');
const app = express();

if (cluster.isMaster) {
  const cpus = os.cpus().length;
  for (let i = 0; i<cpus; i++) {
    cluster.fork();
  }

} else {
    app.get('/', function (req, res) {
        res.send('Hello from Worker ' + cluster.worker.id);
    });

    app.listen(3000);
    console.log(`Worker ${cluster.worker.id} running!`);
}
