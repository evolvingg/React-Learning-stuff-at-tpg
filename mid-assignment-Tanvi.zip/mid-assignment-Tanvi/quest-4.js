const express = require('express');
const api = require('./api');
const app = express();


app.get(`/todos`, (request, resp) => {
    let data = '';
    api.myFirstPromise1.then((successMessage) => {
        data = JSON.stringify(successMessage);
        resp.writeHead(200, { 'Content-Type': 'application/json' });
        resp.end(data);
      }).catch((msg)=>{
          console.log('error');
    })
});
  
app.get(`/todos/:id`, (request, resp) => {
    let userId = Number(request.params.id);
    let ind = '';
    api.myFirstPromise1.then((successMessage) => {
        let elem = successMessage.filter(elem => elem.id === userId);
        ind = JSON.stringify(elem[0]);
        resp.writeHead(200, { 'Content-Type': 'application/json' });
        resp.end(ind);
      }).catch((msg)=>{
          console.log('error');
    })
});
  
let port = 4000;
app.listen(port, () => console.log(`app at http://localhost:${port}`));
