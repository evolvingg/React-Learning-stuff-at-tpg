import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './index.css';
//import "bootstrap/dist/css/bootstrap.min.css";

const Element = React.createElement(
  'div',
  null,
  React.createElement('h1',{className:'hi',id:'chked'},'hello'),
  React.createElement('h1',null,'welcome'),
  'guest'
)

const anotherElement = React.createElement(
  'div', {
    className: 'container',
    children: 'hello  new  world',
  }
)

console.log(Element);

ReactDOM.render(
  //<App />,
  Element,
  document.getElementById('root')
);


