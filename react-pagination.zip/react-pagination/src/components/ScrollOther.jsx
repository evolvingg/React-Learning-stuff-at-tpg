import React from 'react';

export default class ScrollOther extends React.Component {
    called = (event) => {
        const elm = document.getElementById('table-body');
        if(!this.checkVisible(elm)) {
            window.scrollTo({top: elm.offsetTop, behavior: 'smooth'});
        }
    }
    checkVisible = (elm) => {
       var rect = elm.getBoundingClientRect();
       console.log(document.documentElement.clientHeight,window.innerHeight,window.innerWidth,rect.bottom,rect.top);
       var viewHeight = Math.max(document.documentElement.clientHeight, window.innerHeight);
        return !(rect.bottom < 0 || rect.top - viewHeight >= 0);

        //other method
        if(rect.top<window.innerHeight) {
            elm.style.backgroundColor="red";
            return true;
        }
        return false;
    }
    render() {
        return (
            <div className="iwp-details">
                <button onClick={this.called}>check</button>
            <nav className="navbar">
                <div className="container">
                    <div className="navbar-tabs iwp-navbar" id="tabsDiv">
                        <a className="navbar-item  lvx-log" alt="Chart">
                            <span className="is-tab">Chart</span>
                        </a>
                        <a className="navbar-item is-hidden-mobile lvx-log" alt="Market Depth">
                            <span className="is-tab is-active">Market Depth</span>
                        </a>
                        <a className="navbar-item is-hidden-mobile lvx-log" alt="Scores">
                            <span className="is-tab">Scores</span>
                        </a>
                    </div>
                </div>
            </nav>
            <div className="market-depth">
                <div className="actionSection height-with-filter is-6-desktop">
                    <div className="row filter-module" id="table-search">
                        <div className="dropdown is-cursor-pointer">
                            <div className="dropdown-trigger">
                                <div className="filter is-hidden-mobile" aria-haspopup="true" aria-controls="dropdown-menu2">
                                    <span><i className="fa fa-filter" aria-hidden="true"></i></span>
                                    <span>Filter By</span>
                                    <span><i className="fa fa-chevron-down"></i></span>
                                </div>
                            </div>
                            <div className="dropdown-menu display-none" id="dropdown-menu2" role="menu">
                                <div className="dropdown-content">
                                    <div alt="Filter by : Trade" className="dropdown-item lvx-log">
                                        <img src="/public/icons/Checkbox.svg"/>
                                            <span className="colChecked">Bid</span>
                                    </div>
                                    <div alt="Filter by : Trade" className="dropdown-item lvx-log">
                                        <img src="/public/icons/Checkbox.svg"/>
                                            <span className="colChecked">Offer</span>
                                    </div>
                                    <div alt="Filter by : Trade" className="dropdown-item lvx-log">
                                        <img src="/public/icons/Checkbox_checked.svg"/>
                                            <span className="colChecked">Trade</span>
                                    </div>
                                    <div alt="Filter by : Trade" className="dropdown-item lvx-log">
                                        <img src="/public/icons/Checkbox.svg"/>
                                            <span className="colChecked">List</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div alt="" className="tags lvx-log ignoreLogging">
                            <span alt="Clear filter by :Trade" className="tag lvx-log">Trade<i className="fa fa-close "></i></span>
                            <span alt="Clear filter by :Clear all" className="tag clearalltag is-cursor-pointer lvx-log">Clear all</span>
                        </div>
                        </div>
                        <div className="row filter-module drop-downs">
                            <span className="showmeText">Show me :</span>
                            <div className="common-custom-drop-down custom-dd" tabIndex="0">
                                <input readOnly="" placeholder="Time periods" value="All formats"/>
                                    <span className="card-header-icon primarycolor drop-icon">
                                        <i className="fa fa-chevron-down"></i>
                                    </span>
                                    <div className="dropdown-menu-custom pointed-dd ">
                                        <div className="dropdown-content dropdown-content-cutom" >
                                        </div>
                                    </div>
                            </div>
                            <div className="common-custom-drop-down custom-dd" tabIndex="0">
                                <input readOnly="" placeholder="Time periods" value="All formats"/>
                                    <span className="card-header-icon primarycolor drop-icon">
                            <div className="common-custom-drop-down custom-dd" tabIndex="0">
                                <input readOnly="" placeholder="Time periods" value="All formats"/>
                                    <span className="card-header-icon primarycolor drop-icon">
                                        <i className="fa fa-chevron-down"></i>
                                    </span>
                                    <div className="dropdown-menu-custom pointed-dd ">
                                        <div className="dropdown-content dropdown-content-cutom" >
                                        </div>
                                    </div>
                            </div>
                                        <i className="fa fa-chevron-down"></i>
                                    </span>
                                    <div className="dropdown-menu-custom pointed-dd ">
                                        <div className="dropdown-content dropdown-content-cutom" >
                                        </div>
                                    </div>
                            </div>
                            <div className="common-custom-drop-down custom-dd" tabIndex="0">
                                <input readOnly="" placeholder="Time periods" value="All formats"/>
                                    <span className="card-header-icon primarycolor drop-icon">
                                        <i className="fa fa-chevron-down"></i>
                                    </span>
                                    <div className="dropdown-menu-custom pointed-dd ">
                                        <div className="dropdown-content dropdown-content-cutom" >
                                        </div>
                                    </div>
                            </div>
                            <div className="common-custom-drop-down custom-dd" tabIndex="0">
                                <input readOnly="" placeholder="Time periods" value="All formats"/>
                                    <span className="card-header-icon primarycolor drop-icon">
                                        <i className="fa fa-chevron-down"></i>
                                    </span>
                                    <div className="dropdown-menu-custom pointed-dd ">
                                        <div className="dropdown-content dropdown-content-cutom" >
                                        </div>
                                    </div>
                            </div>

                            <div className="common-custom-drop-down custom-dd" tabIndex="0">
                                <input readOnly="" placeholder="Time periods" value="Last 90 days"/>
                                    <span className="card-header-icon primarycolor drop-icon">
                                        <i className="fa fa-chevron-down"></i>
                                    </span>
                                    <div className="dropdown-menu-custom pointed-dd ">
                                        <div className="dropdown-content dropdown-content-cutom" >
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                                    <div className="custom-table">
                                        <div className="table-header">
                                            <div className="columns">
                                                <div className="column is-2-desktop" data-column="priceDate">
                                                    <span>Date</span><img src="/public/icons/sort_grey.svg" className="sortImage"/>
                                                </div>
                                                <div className="column is-2-desktop has-text-centered" data-column="priceType">
                                                    <span>Price type</span><img src="/public/icons/sort_grey.svg" className="sortImage"/>
                                                </div>
                                                <div className="column is-2-desktop has-text-centered" data-column="packSize,bottleSize">
                                                    <span>Unit size</span><img src="/public/icons/sort_grey.svg" className="sortImage"/>
                                                </div>
                                                <div className="column is-1-desktop sortArrowclassName" data-column="quantity">
                                                    <span>Quantity</span><img src="/public/icons/sort_grey.svg" className="sortImage"/>
                                                </div>
                                                <div className="column is-2-desktop has-text-centered" data-column="price">
                                                    <span>Price</span><img src="/public/icons/sort_ac.svg" className="sortImage"/>
                                                </div>
                                                <div className="column is-1-column sortArrowclassName" data-column="contractType">
                                                    <span>Contract</span><img src="/public/icons/sort_grey.svg" className="sortImage"/>
                                                </div>
                                                <div className="column is-1-desktop has-text-centered" data-column="ci">
                                                    <span>CI</span>
                                                </div>
                                                <div className="column is-1-desktop" data-column="isSold">
                                                    <span>Sold</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="mainOverlay" className="main-overlay">
                                        </div>
                                        <div className="table-body bottom-border-line" id="table-body">
                                            <div id="table-row-0" className="columns is-multiline row ">
                                                <span className="column is-2-desktop">
                                                    <span alt="LWIN 112135920040300750, ">
                                                        <span>24/07/2019</span>
                                                    </span>
                                                </span>
                                                <span className="column is-2-desktop has-text-capitalize has-text-centered">
                                                    <span alt="LWIN 112135920040300750, ">
                                                        <span>trade</span>
                                                        </span>
                                                        </span>
                                                <span className="column is-2-desktop has-text-centered">
                                                    <span alt="LWIN 112135920040300750, ">
                                                        <span><span>3</span><span>x75</span></span></span>
                                                        </span>
                                                        
                                                <span className="column  is-1-desktop has-text-centered">
                                                    <span alt="LWIN 112135920040300750, "><span>1</span></span></span>
                                                <span className="column is-2-desktop has-text-centered less-padding">
                                                    <span className="trade-bg md-my-position " alt="LWIN 112135920040300750, ">
                                                        <span>$372</span></span></span>
                                                <span className="column  is-1-desktop has-text-centered">
                                                    <span alt="LWIN 112135920040300750, "><span>Special</span></span></span>
                                                <span className="column  is-1-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span>
                                                    </span>
                                                    </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span></span>
                                                        </span>
                                                    </span>
                                                </div>
                                                <div id="table-row-1" className="columns is-multiline row ">
                                                    <span className="column is-2-desktop">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>06/09/2019</span>
                                                        </span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-capitalize has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>trade</span>
                                                        </span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>
                                                            <span>3</span>
                                                            <span>x75</span>
                                                            </span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>4</span>
                                                        </span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-centered less-padding">
                                                        <span className="trade-bg md-my-position " alt="LWIN 112135920040300750, ">
                                                            <span>$664</span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>SIB</span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, "><span>
                                                    </span>
                                                </span>
                                            </span>
                                                <span className="column  is-1-desktop has-text-centered">
                                                    <span alt="LWIN 112135920040300750, ">
                                                        <span>
                                                        </span>
                                                    </span>
                                                </span>
                                            </div>
                                                                    <div id="table-row-2" className="columns is-multiline row ">
                                                                        <span className="column is-2-desktop">
                                                                            <span alt="LWIN 112135920040300750, ">
                                                                                <span>27/06/2019</span>
                                                                            </span>
                                                                        </span>                                        
                                                    <span className="column is-2-desktop has-text-capitalize has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>trade</span>
                                                        </span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>
                                                                <span>3</span>
                                                                <span>x75</span>
                                                            </span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>1</span>
                                                        </span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-centered less-padding">
                                                        <span className="trade-bg  " alt="LWIN 112135920040300750, ">
                                                            <span>$705</span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>SIB</span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span></span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span></span>
                                                        </span>
                                                    </span>
                                                </div>
                                                <div id="table-row-3" className="columns is-multiline row ">
                                                    <span className="column is-2-desktop">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>13/08/2019</span>
                                                        </span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-capitalize has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>trade</span>
                                                        </span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>
                                                                <span>3</span>
                                                                <span>x75</span>
                                                            </span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>1</span>
                                                        </span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-centered less-padding">
                                                        <span className="trade-bg  " alt="LWIN 112135920040300750, ">
                                                            <span>$723</span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>SIB</span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span></span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span></span>
                                                        </span>
                                                    </span>
                                                </div>
                                                <div id="table-row-4" className="columns is-multiline row ">
                                                    <span className="column is-2-desktop">
                                                        <span alt="LWIN 112135920040300750, "><span>07/08/2019</span></span></span><span className="column is-2-desktop has-text-capitalize has-text-centered"><span alt="LWIN 112135920040300750, ">
                                                            <span>trade</span></span></span>
                                                        <span className="column is-2-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span><span>3</span><span>x75</span></span></span></span><span className="column  is-1-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span>1</span></span></span>
                                                        <span className="column is-2-desktop has-text-centered less-padding"><span className="trade-bg  " alt="LWIN 112135920040300750, "><span>$728</span></span></span><span className="column  is-1-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span>SIB</span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, "><span></span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span>
                                                        </span>
                                                    </span>
                                                    </span>
                                                </div>
                                                <div id="table-row-5" className="columns is-multiline row ">
                                                    <span className="column is-2-desktop">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span>28/06/2019</span>
                                                        </span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-capitalize has-text-centered">
                                                        <span alt="LWIN 112135920040300750, "><span>trade</span></span>
                                                        </span>
                                                    <span className="column is-2-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, ">
                                                            <span><span>3</span><span>x75</span></span></span></span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, "><span>2</span></span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-centered less-padding">
                                                        <span className="trade-bg  " alt="LWIN 112135920040300750, ">
                                                            <span>$728</span>
                                                        </span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040300750, "><span>SIB</span></span></span><span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, ">
                                                                <span></span>
                                                            </span>
                                                        </span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, ">
                                                                <span></span>
                                                            </span>
                                                        </span>
                                                    </div>
                                                    <div id="table-row-6" className="columns is-multiline row ">
                                                        <span className="column is-2-desktop">
                                                            <span alt="LWIN 112135920040300750, ">
                                                                <span>07/08/2019</span></span></span>
                                                        <span className="column is-2-desktop has-text-capitalize has-text-centered">
                                                            <span alt="LWIN 112135920040300750, "><span>trade</span></span></span><span className="column is-2-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span><span>3</span><span>x75</span></span></span></span><span className="column  is-1-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span>1</span></span></span>
                                                        <span className="column is-2-desktop has-text-centered less-padding"><span className="trade-bg  " alt="LWIN 112135920040300750, "><span>$729</span></span>
                                                        </span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, "><span>SIB</span></span></span><span className="column  is-1-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span></span></span>
                                                            </span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, "><span></span></span>
                                                        </span>
                                                    </div>
                                                    <div id="table-row-7" className="columns is-multiline row ">
                                                        <span className="column is-2-desktop">
                                                            <span alt="LWIN 112135920040300750, ">
                                                                <span>28/08/2019</span></span></span>
                                                        <span className="column is-2-desktop has-text-capitalize has-text-centered">
                                                            <span alt="LWIN 112135920040300750, ">
                                                                <span>trade</span></span></span>
                                                        <span className="column is-2-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, "><span><span>3</span><span>x75</span></span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, "><span>1</span></span></span>
                                                        <span className="column is-2-desktop has-text-centered less-padding">
                                                            <span className="trade-bg  " alt="LWIN 112135920040300750, "><span>$742</span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, "><span>SIB</span></span></span><span className="column  is-1-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span></span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span></span>
                                                        </span></span>
                                                    </div>
                                                    <div id="table-row-8" className="columns is-multiline row ">
                                                        <span className="column is-2-desktop">
                                                            <span alt="LWIN 112135920040300750, "><span>24/07/2019</span>
                                                        </span></span>
                                                        <span className="column is-2-desktop has-text-capitalize has-text-centered">
                                                            <span alt="LWIN 112135920040300750, "><span>trade</span></span></span>
                                                        <span className="column is-2-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, ">
                                                                <span><span>3</span><span>x75</span></span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, "><span>1</span></span></span>
                                                        <span className="column is-2-desktop has-text-centered less-padding">
                                                            <span className="trade-bg md-my-position " alt="LWIN 112135920040300750, "><span>$743</span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040300750, "><span>SIB</span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span></span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered"><span alt="LWIN 112135920040300750, "><span></span></span></span>
                                                    </div>
                                                    <div id="table-row-9" className="columns is-multiline row ">
                                                        <span className="column is-2-desktop">
                                                            <span alt="LWIN 112135920040600750, ">
                                                                <span>23/07/2019</span>
                                                            </span>
                                                        </span>
                                                        <span className="column is-2-desktop has-text-capitalize has-text-centered">
                                                            <span alt="LWIN 112135920040600750, "><span>trade</span></span></span>
                                                        <span className="column is-2-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040600750, "><span><span>6</span><span>x75</span>
                                                            </span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040600750, ">
                                                                <span>1</span></span></span>
                                                        <span className="column is-2-desktop has-text-centered less-padding">
                                                            <span className="trade-bg  " alt="LWIN 112135920040600750, ">
                                                                <span>$1,494</span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040600750, "><span>SIB</span></span></span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040600750, ">
                                                                <span></span>
                                                            </span>
                                                        </span>
                                                        <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040600750, "><span>
                                                            </span>
                                                        </span>
                                                    </span>
                                                </div>
                                                <div id="table-row-10" className="columns is-multiline row ">
                                                    <span className="column is-2-desktop">
                                                        <span alt="LWIN 112135920040600750, ">
                                                            <span>25/07/2019</span></span></span>
                                                    <span className="column is-2-desktop has-text-capitalize has-text-centered">
                                                        <span alt="LWIN 112135920040600750, ">
                                                            <span>trade</span></span></span>
                                                    <span className="column is-2-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040600750, "><span><span>6</span><span>x75</span>
                                                        </span></span>
                                                    </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040600750, "><span>1</span></span>
                                                    </span>
                                                    <span className="column is-2-desktop has-text-centered less-padding">
                                                        <span className="trade-bg  " alt="LWIN 112135920040600750, ">
                                                            <span>$1,497</span></span></span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                        <span alt="LWIN 112135920040600750, ">
                                                            <span>SIB</span></span>
                                                        </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                            <span alt="LWIN 112135920040600750, ">
                                                                <span></span></span>
                                                            </span>
                                                    <span className="column  is-1-desktop has-text-centered">
                                                                <span alt="LWIN 112135920040600750, "><span>
                                                                </span>
                                                            </span>
                                                        </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
        );
    }
}