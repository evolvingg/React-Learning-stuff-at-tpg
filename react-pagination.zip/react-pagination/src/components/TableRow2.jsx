import React from 'react';

class TableRow2 extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        const {elemHeight,rowData} = this.props;
        return (
            <div className="row" style={{height:elemHeight}}>
                <div>{rowData.html_url}</div>
            </div>
        )
    }
}

export default TableRow2;