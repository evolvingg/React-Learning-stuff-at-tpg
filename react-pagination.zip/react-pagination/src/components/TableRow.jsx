import React from 'react';

class TableRow extends React.Component {
    constructor(props) {
        super(props);
    }
    // componentDidMount() {
    //     const elem = document.getElementById('row-'+this.props.rowId);
    //     const compHeight = elem && elem.getBoundingClientRect().height;
    //     console.log('height::',compHeight,'---',this.props.rowId)
    //     this.returnRefs(compHeight);
    //     console.log('called again')
    // }
    componentDidUpdate(prevProps) {
        console.log('prev::',prevProps,this.props)
        if(prevProps.rowData.id !== this.props.rowData.id ) {
            const elem = document.getElementById('row-'+this.props.rowId);
            const compHeight = elem && elem.getBoundingClientRect().height;
            console.log('clalede::',compHeight,'---',this.props.rowId)
            this.returnRefs(compHeight);
        }
    }
    returnRefs = (compHeight) => {
        this.props.setRef(compHeight, this.props.rowId );
    }
    render() {
        const {rowData,rowId} = this.props;
        return (
            <div className="row" id={`row-${rowId}`}>
                <div>{rowData.avatar_url} + {'   '+  rowData.events_url+ '   '+ rowData.followers_url + '   '+rowData.following_url }<img src={rowData.avatar_url}/></div>
                <div>{rowData.login}</div>
                <div>{`${rowData.site_admin}`}</div>
                <div>{rowData.node_id}</div>
            </div>
        )
    }
}

export default TableRow;