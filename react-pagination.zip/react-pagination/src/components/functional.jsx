import React , {useState,useContext} from 'react';
//import Row from './Row';


export default function Greeting(props) {
    const [name, setName] = useState('Tanvi');
    const [surName, setsurName] = useState('Singh');

    function handleNameChange(e) {
        setName(e.target.value);
    }

    function handleSurNameChange(e) {
        setsurName(e.target.value);
    }

    return (
        <section>
            <label name="Name">
                <input 
                value={name}
                onChange={handleNameChange} 
                />
            </label>
            <label name="LastName">
                <input 
                value={surName}
                onChange={handleSurNameChange} 
                />
            </label>
            <div>
                <span>{name}</span>
                <span style={{margin: "20px"}}>{surName}</span>
            </div>
        </section>
    )
}
