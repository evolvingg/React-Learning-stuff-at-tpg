import React from 'react';

export default class Another extends React.Component {
    constructor(props){
        super(props);
    }
    componentDidMount(){
        console.log('in did mount')
    }
    componentDidUpdate(){
        console.log('did update')
    }
    componentWillReceiveProps(){
        console.log('will receive props');
    }
    getSnapshotBeforeUpdate(){
        console.log('in snapshot')
    }
    render() {
        console.log('in render')
        return (
            <div className="divInQ">
                hi......  {this.props.comp}
                <a href="#">google</a>
            </div>
        )
    }
}