import React from 'react';
import ReactDOM from 'react-dom';
import Another from './Another';

class ScrollWork extends React.Component {
    
    handleClick = ()  => {
        const elem = ReactDOM.findDOMNode(this.textVal);
        elem.scrollIntoView({
            behavior: 'smooth',
            block: 'start',
          });
    }
    
    render() {
        return (
            <div>
                <div className="divtochk" ref={(val) => {    this.textVal = val }}>
                    mydiv
                    
                </div>
                <Another comp="eqrqwqrw" />
                <button onClick={this.handleClick}>click</button>
            </div>    
        )
    }
}

export default ScrollWork;