import React, { Component } from 'react';

import Truncate from 'react-truncate';
 
class ReadMore extends Component {
    constructor(props) {
        super(props);
 
        this.state = {
            expanded: false,
            truncated: false
        };
    }
 
    handleTruncate = (truncated) => {
        if (this.state.truncated !== truncated) {
            this.setState({
                truncated
            });
        }
    }
 
    toggleLines = (event) => {
        event.preventDefault();
 
        this.setState({
            expanded: !this.state.expanded
        });
    }

    calledOnClick = (event) => {
        console.log(event.target);
        console.log(event.target.parentElement.parentElement.parentElement);
        debugger;
    }
 
    render() {
        const {
            children,
            more,
            less,
            lines 
        } = this.props;
 
        const {
            expanded,
            truncated 
        } = this.state;


 
        return (
            <div className="trunc">
                <Truncate
                    lines={!expanded && lines}
                    ellipsis={(
                        <span>... <a href='#' onClick={this.toggleLines}>{more}</a></span>
                    )}
                    onTruncate={this.handleTruncate}
                >
                    {children}
                </Truncate>
                {!truncated && expanded && (
                    <span> <a href='#' onClick={this.toggleLines}>{less}</a></span>
                )}
                <div className="truncation">wr rettet etre t etet teegfdvs cdvfd gr ggrrger 45t 5 fdaa d dsfgtrgtry6  htgrtgrgt
                </div>

                <span width="153.5875" alt="LWIN 114134620150300750, IWP - Scarecrow, Cabernet Sauvignon, 2015, /#/wine-page?lwin11=11413462015">
                    <span>
                        <span>
                        <span className="elem" onClick={this.calledOnClick} className='hi'>
                            Scarecrow, Cabernet
                            <span alt="LWIN 114134620150300750, IWP - Scarecrow, Cabernet Sauvignon, 2015, /#/wine-page?lwin11=11413462015">..., 2015</span>
                        </span>
                        </span>
                        </span>
                        {/* <span style="position: fixed; visibility: hidden; top: 0px; left: 0px;">
                            <span alt="LWIN 114134620150300750, IWP - Scarecrow, Cabernet Sauvignon, 2015, /#/wine-page?lwin11=11413462015">..., 2015</span>
                            </span> */}
                        </span>
            </div>
        );
    }
}
 
ReadMore.defaultProps = {
    lines: 3,
    more: 'Read more',
    less: 'Show less'
};
 
export default ReadMore;