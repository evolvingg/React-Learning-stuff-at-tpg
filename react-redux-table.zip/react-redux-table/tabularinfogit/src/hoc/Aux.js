//since no jsx therefore react import not needed
const Aux = (props) => props.children;

export default Aux;