const http = require('https');
let url = `https://jsonplaceholder.typicode.com/todos`;

let myFirstPromise1 = new Promise((resolve, reject) => {
    let req = http.get(
        url,
        (res) => {
            let body = "";
            res.on("data", data => {
              body += data;
            });
            res.on("end", () => {
              body = JSON.parse(body);
              return resolve(body);
            });
        }
      );
    req.on('error', (e) => console.log(e));
    req.end();
  });

exports.myFirstPromise1 = myFirstPromise1;
