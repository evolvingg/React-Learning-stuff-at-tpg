
const ar = [1,2,3,4,5];
const myFunc = (val) => {
    setTimeout(()=> {
        console.log(val);
    },500)
}

ar.map(item => myFunc(item));
